# Lal Kitab Kundli – Android project

## APK banane ke steps (Android Studio)
1. Android Studio (free) install karein: https://developer.android.com/studio
2. File > Open > is poore folder (LalKitabKundli_Android) ko chunein. Internet chahiye (Gradle sync pehli baar libraries download karta hai).
3. Sync khatam hone par: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK yahan milegi: app/build/outputs/apk/debug/app-debug.apk
   Phone mein copy karke install karein (Unknown sources allow karna padega).

## Play Store ke liye
Build > Generate Signed Bundle / APK > Android App Bundle (.aab) chunein aur apna keystore banayein.
Keystore aur uska password surakshit rakhein.

## Page badalna ho to
app/src/main/assets/index.html ko naye version se replace karein aur dobara build karein.
